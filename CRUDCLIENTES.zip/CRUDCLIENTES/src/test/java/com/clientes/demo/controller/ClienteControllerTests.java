package com.clientes.demo.controller;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.clientes.demo.entity.Cliente;
import com.clientes.demo.service.ClienteService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ClienteControllerTests {

	
	private static final Logger log = LoggerFactory.getLogger(ClienteControllerTests.class);

	@InjectMocks
	private ClienteController clientesController = new ClienteController();
	
	@Mock
	private  ClienteService service;
	
	
	@Test
	public void getAllClientes() {

		log.info("Test 1");


		List<Cliente> listRwturn = new ArrayList<>();
		Cliente cliente = new Cliente();
		cliente.setId(1);
		cliente.setNombre("Fulano");
		cliente.setApellidos("De tal");
		
		listRwturn.add(cliente);

		when(service.list()).thenReturn(listRwturn);

		
		
		try {
			List<Cliente> interableLista = (List<Cliente>) clientesController.list();
			log.info("respuestaServicio= " + interableLista);
			
			assertNotNull(interableLista);
		} catch (Exception e) {
			fail("FALLO LA PRUEBA TEST1");
		}

		
	

	}
	
}
