package com.clientes.demo;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
class CrudclientesApplicationTests {
	
	private static final Logger log = LoggerFactory.getLogger(CrudclientesApplicationTests.class);

	@BeforeAll
	public static void beforeClassTest() {
		log.info("Se ejecuta antes ");
	}
	
	@Test
	public void Test1() {
		log.info("test que compara que sea el mismo resultado de la suma");
		Assertions.assertEquals(2, 1 + 1);
	}

	@Test
	public void Test2() {
		log.info("test 2+2=4 que compara igual la suma y que el resultado sea el esperado");
		Assertions.assertEquals(4, 2 + 2);
	}
	
	@AfterAll
	public static void afterTest() {
		log.info("se ejecuta despues de todos los test");
	}
	
}
