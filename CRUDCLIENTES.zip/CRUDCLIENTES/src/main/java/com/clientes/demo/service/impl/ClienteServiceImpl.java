package com.clientes.demo.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.clientes.demo.entity.Cliente;
import com.clientes.demo.service.ClienteService;

@Service
public class ClienteServiceImpl implements ClienteService{


	private List<Cliente> clientes;


	{
		clientes = new ArrayList<>();
		clientes.add(new Cliente(1, "Ruben", "Landa Escudero"));
		clientes.add(new Cliente(2, "Katy", "Rivera Medina"));
		clientes.add(new Cliente(3, "Jose", "Perez Leon"));
		clientes.add(new Cliente(4, "Patricia", "Rodriguez Perez"));
		clientes.add(new Cliente(5, "Oscar", "Catalan Fuentes"));
		clientes.add(new Cliente(6, "Maria", "Antunez Heredia"));
		clientes.add(new Cliente(7, "Prueba", "GS"));
		clientes.add(new Cliente(8, "Oscar", "GS"));
	}

	@Override
	public List<Cliente> list() {
		return clientes;
	}

	// Metodo Buscar Cliente

	@Override
	public Cliente find(int id) {
		for (Cliente cliente : clientes) {
			if (cliente.getId() == id) {
				return cliente;
			}
		}
		return null;
	}

	// Metodo Guardar Cliente
	@Override
	public Cliente save(Cliente cli) {
		clientes.add(cli);
		return cli;
	}

	// Metodo Actualizar Cliente
	@Override
	public Cliente update(int id, Cliente cli) {
		int index = 0;
		for (Cliente l : clientes) {
			if (l.getId() == id) {
				cli.setId(id);
				clientes.set(index, cli);
			}
		}
		return cli;
	}

	// Metodo Eliminar Cliente
	@Override
	public boolean delete(int id) {
		for (Cliente c : clientes) {
			if (c.getId() == id) {
				return clientes.remove(c);
			}
		}
		return false;
	}

}
