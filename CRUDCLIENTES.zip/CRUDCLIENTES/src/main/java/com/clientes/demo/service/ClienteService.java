package com.clientes.demo.service;

import java.util.List;

import com.clientes.demo.entity.Cliente;

public interface ClienteService {

	public List<Cliente> list();
	
	public Cliente find(int id);
	
	public Cliente save(Cliente cli);
	
	public Cliente update(int id, Cliente cli);
	
	public boolean delete(int id);
}
